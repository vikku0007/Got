import React from 'react';
import { Container } from 'reactstrap';
import './Pages.css';

function Home() {
    return (
        <>
            <div className="mt-5 mb-5">
                <Container>
                    <h3>Home Page</h3>
                </Container>
            </div>
        </>
    );
}

export default Home;
 